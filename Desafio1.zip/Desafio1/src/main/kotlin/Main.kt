import java.util.*

fun main( ) {
    val car = Vehicle("aaa123", VehicleType.AUTO, Calendar.getInstance(),"779Dia" )
    val moto = Vehicle("123aaa", VehicleType.MOTO, Calendar.getInstance(),"Dia779" )
    val minibus = Vehicle("aa23a1", VehicleType.MINIBUS, Calendar.getInstance())
    val bus = Vehicle("a123aa", VehicleType.BUS, Calendar.getInstance(),"77ia9D" )

    val parking = Parking(mutableSetOf(car,moto,minibus,bus))

//    println(parking.vehicles.contains(car))
//    println(parking.vehicles.contains(moto))
//    println(parking.vehicles.contains(minibus))
//    println(parking.vehicles.contains(bus))

    val carDos = Vehicle("aaa123", VehicleType.AUTO, Calendar.getInstance(),"779Dia" )
    val isCarDosInserted = parking.vehicles.add(carDos)
    println(isCarDosInserted)

    parking.vehicles.remove(car)
    println(parking.vehicles.contains(car))


}



