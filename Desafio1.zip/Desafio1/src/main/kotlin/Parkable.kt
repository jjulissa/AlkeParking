import java.lang.reflect.Type
import kotlin.math.ceil

data class Parkable (val vehicles:MutableSet<Vehicle>) {

    var totalCarDia:Int=0
    var totalGanaciaDia:Int=0

    fun checkOutVehicle(plate: String, onSuccess: (Int)->Unit, onError: (String)->Unit) {

        val plateTotal = vehicles.map { it }.filter { it.plate == plate }
        if (plateTotal.isNotEmpty()) {
            val vehicleCheck = plateTotal[0]
            val tarifaVehicleCheck = calcularTarifa(vehicleCheck.vehicleType,vehicleCheck.parkedTime.toInt(),true)
            onSuccess(tarifaVehicleCheck)
            vehicles.remove(vehicleCheck)
            totalCarDia++
            totalGanaciaDia+=tarifaVehicleCheck

        } else {
            onError
        }

    }

    fun calcularTarifa(type: VehicleType, parkedTime: Int, hasDiscountCard: Boolean): Int {
        val price: Double
        var typeFee: Int =0
//        var totalPrice:Int =0

        if (parkedTime > 120) {
            val blocks = (parkedTime.toFloat() - 120) / 15
            val roundBlocks = (ceil(blocks)).toInt()
             typeFee = when (type) {
                VehicleType.AUTO -> VehicleType.AUTO.tarifa + (roundBlocks * 5)
                VehicleType.MOTO -> VehicleType.MOTO.tarifa + (roundBlocks * 5)
                VehicleType.BUS -> VehicleType.BUS.tarifa + (roundBlocks * 5)
                VehicleType.MINIBUS -> VehicleType.MINIBUS.tarifa + (roundBlocks * 5)

            }
        } else {
            typeFee = type.tarifa
            return typeFee
        }

          if (hasDiscountCard) {
            val discount = typeFee - (((typeFee * 15) / 100))
            println("Tienes que pagar $discount")
        }
        else {
             typeFee
         }

//Error
    }
}