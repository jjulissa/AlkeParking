
data class Parking(val vehicles:MutableSet<Vehicle>,
                   val maximoVehicle:Int=20,
                   val parkable: Parkable=Parkable(vehicles),
                   val gananciasInfo:Pair<Int,Int> = Pair(parkable.totalCarDia,parkable.totalGanaciaDia)
)

{
    //¿Por qué se define vehicles como un Set? Para evitar que los vehiculos sean duplicados
//Recuerda en qué se diferencian los Set de los Array. ¿Podrían existir dos vehículos iguales?
//    Dos vehículos misma Marca, Si,
//    Dos vehículos mismo Patente, No


    fun addVehicle(vehicle: Vehicle): Boolean {
        if (vehicles.size < maximoVehicle) {
            vehicles.add(vehicle)
            println("Welcome to AlkeParking!")
            return true
        } else {
            println("Sorry, the check-in failed")
            return false
        }
    }

    fun ganancias() {
            gananciasInfo.first
            gananciasInfo.second
            println("${gananciasInfo.first} vehicles, have checked out and have earnings of ${gananciasInfo.second} ")
    }


    fun listVehicles():List<Unit> {
        return vehicles.map { it.plate }
    }

}



