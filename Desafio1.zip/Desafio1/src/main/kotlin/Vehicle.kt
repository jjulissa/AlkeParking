import java.util.Calendar
import java.util.Date

const val MINUTES_IN_MILISECONDS =60000

data class Vehicle(val plate:String,
                   val vehicleType: VehicleType,
                   val checkInTime:Calendar=Calendar.getInstance(),
                   val discountCard:String?=null,
                   val parkedTime:Long=(Calendar.getInstance().timeInMillis-checkInTime.timeInMillis) / MINUTES_IN_MILISECONDS
) {
    override fun equals(other: Any?): Boolean {
        if (other is Vehicle) {
            return this.plate == other.plate
        } else {
            return super.equals(other)
        }
    }
        override fun hashCode():Int{
            return this.plate.hashCode()
        }





    }









