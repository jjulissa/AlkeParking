enum class VehicleType(val tarifa:Int) {
    AUTO( 20),
    MOTO( 15),
    MINIBUS( 25),
    BUS( 30)
}